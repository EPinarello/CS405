// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//custom exception created
class myException : public std::exception {
public:
    virtual const char* what() const throw() {
        return "Custom Exception";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    //Completed: Throw any standard exception
    throw std::exception();


    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    //Completed: catch standard exception and displays message and e.what()
    catch (std::exception e) {
        std::cout << "Error" << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    //Completed: throw custom exception
    throw myException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //float result;
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    //Completed: throw exception for dividing by zero
    try {
        float result = (num / den);
        throw std::exception("Cannot divide by zero");
    }
    catch (std::exception& e) {
        std::cout << e.what();
    }
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //Completed: exception handler for exceptions thrown only by divide
    catch (std::exception& e) {
        std::cout << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "EPinarello Module Four Exceptions" << std::endl;
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }

    //Completed: exception catch for my custom exception
    catch (myException& e) {
        std::cout << "Custom exception" << e.what() << std::endl;
    }

    //Completed: exception catch for std::exception
    catch (std::exception& e) {
        std::cout << "Standard exception" << e.what() << std::endl;
    }

    //Completed: exception catch for uncaught exception
    catch (...) {
        std::cout << "Uncaught exception" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
